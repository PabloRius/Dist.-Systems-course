#ifndef UTILS_H
#define UTILS_H 1

void print_double_array(double *array, int size);

#endif /* UTILS_H */